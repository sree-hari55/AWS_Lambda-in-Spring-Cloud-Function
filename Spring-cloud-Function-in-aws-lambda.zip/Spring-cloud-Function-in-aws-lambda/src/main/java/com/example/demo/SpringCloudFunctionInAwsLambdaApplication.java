package com.example.demo;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.AsyncResult;

import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.example.demo.dto.Account;
import com.example.demo.service.AccountService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication

public class SpringCloudFunctionInAwsLambdaApplication {

	private final Logger LOGGER=LoggerFactory.getLogger(SpringCloudFunctionInAwsLambdaApplication.class);

	@Autowired
	private ObjectMapper objectMapper=new ObjectMapper();
	
	@Autowired
	private AccountService accountService;

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudFunctionInAwsLambdaApplication.class, args);
	}

	@Bean
	public Function<APIGatewayProxyRequestEvent,List<Account>> getAccountByAccountHolderName(){
		return (input) ->accountService.getAccounts()
				.stream()
				.filter(account -> account.getAccountHolderName().equals(input.getQueryStringParameters().get("name")))
				.collect(Collectors.toList());
	}	
	
	
	@Bean
	
	public Function<Account,Future<String>> createAccount(){
		return value ->{
			LOGGER.info("create account request from req:{}"+value);
			accountService.createAccount(value);
			return new AsyncResult<String>("Account created sucessfully.");
		};
	}


	@Bean
	public Function<APIGatewayProxyRequestEvent,APIGatewayProxyResponseEvent> getResponse(){
		return value ->{
			String requestBody=value.getBody();

			try {
				Account account=objectMapper.readValue(requestBody,Account.class);
				accountService.createAccount(account);
			}
			catch (JsonProcessingException e){  e.printStackTrace(); } 

			APIGatewayProxyResponseEvent responseEvent=new APIGatewayProxyResponseEvent();
			responseEvent.setStatusCode(200);
			responseEvent.setBody("Account created sucessfully");
			responseEvent.setHeaders(Collections.singletonMap("Content-Type", "application/json"));
			return responseEvent;
		};
	}

	@Bean
	public Supplier<List<Account>> getAccounts() throws JsonProcessingException{
		List<Account> accounts=accountService.getAccounts();
		LOGGER.info("Account List: {}"+accounts);
		LOGGER.info("Accounts List size:{}"+accounts.size());
		return () -> accounts;
	}

	@Bean
	public Consumer<APIGatewayProxyRequestEvent> showCosumeMessage(){
		return (input) ->System.out.println("The Cosumed Name is :{}"+input.getQueryStringParameters().get("name"));
	}
}

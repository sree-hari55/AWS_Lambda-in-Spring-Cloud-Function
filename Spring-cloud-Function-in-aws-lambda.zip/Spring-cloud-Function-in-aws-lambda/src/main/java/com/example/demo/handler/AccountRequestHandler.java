package com.example.demo.handler;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

import com.example.demo.dto.Account;

//This class is responsible for AWS API Gateway Request Handler

public class AccountRequestHandler extends SpringBootRequestHandler<Account, Object>{

}
